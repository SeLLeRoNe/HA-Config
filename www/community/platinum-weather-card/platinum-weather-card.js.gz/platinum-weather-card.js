export{W as WeatherCard}from"./platinum-weather-card-ec361ffe.js";
